"""Lighthouse performance tests."""

